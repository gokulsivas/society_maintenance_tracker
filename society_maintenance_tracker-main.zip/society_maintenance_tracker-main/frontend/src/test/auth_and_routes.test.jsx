import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider, AuthContext, useAuth } from '../context/AuthContext';
import ProtectedRoute from '../components/common/ProtectedRoute';
import * as authApi from '../api/auth';

describe('Auth & Protected Routing', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.clearAllMocks();
  });

  function TestConsumer() {
    const { user, isAuthenticated, isAdmin, isResident, logout } = useAuth();
    return (
      <div>
        <div data-testid="auth-state">{isAuthenticated ? 'LOGGED_IN' : 'LOGGED_OUT'}</div>
        <div data-testid="user-name">{user?.name || 'NONE'}</div>
        <div data-testid="user-role">{user?.role || 'NONE'}</div>
        <div data-testid="is-admin">{isAdmin ? 'YES' : 'NO'}</div>
        <button onClick={logout}>Sign out</button>
      </div>
    );
  }

  it('restores session when valid token exists in localStorage', async () => {
    localStorage.setItem('token', 'mock.jwt.token');
    vi.spyOn(authApi, 'getMe').mockResolvedValueOnce({
      id: 1,
      name: 'Alice Resident',
      email: 'alice@society.com',
      role: 'RESIDENT',
    });

    render(
      <AuthProvider>
        <TestConsumer />
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.getByTestId('auth-state')).toHaveTextContent('LOGGED_IN');
      expect(screen.getByTestId('user-name')).toHaveTextContent('Alice Resident');
      expect(screen.getByTestId('user-role')).toHaveTextContent('RESIDENT');
    });
  });

  it('clears session if getMe fails with 401/expired token', async () => {
    localStorage.setItem('token', 'expired.token');
    vi.spyOn(authApi, 'getMe').mockRejectedValueOnce({ response: { status: 401 } });

    render(
      <AuthProvider>
        <TestConsumer />
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.getByTestId('auth-state')).toHaveTextContent('LOGGED_OUT');
      expect(localStorage.getItem('token')).toBeNull();
    });
  });

  it('redirects unauthenticated users to /signin on ProtectedRoute', async () => {
    render(
      <AuthProvider>
        <MemoryRouter initialEntries={['/dashboard']}>
          <Routes>
            <Route path="/signin" element={<div>SIGNIN_PAGE</div>} />
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <div>PROTECTED_DASHBOARD</div>
                </ProtectedRoute>
              }
            />
          </Routes>
        </MemoryRouter>
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.getByText('SIGNIN_PAGE')).toBeInTheDocument();
      expect(screen.queryByText('PROTECTED_DASHBOARD')).not.toBeInTheDocument();
    });
  });

  it('blocks residents from adminOnly protected routes', async () => {
    localStorage.setItem('token', 'valid.token');
    vi.spyOn(authApi, 'getMe').mockResolvedValueOnce({
      id: 2,
      name: 'Bob Resident',
      email: 'bob@society.com',
      role: 'RESIDENT',
    });

    render(
      <AuthProvider>
        <MemoryRouter initialEntries={['/admin/dashboard']}>
          <Routes>
            <Route path="/dashboard" element={<div>RESIDENT_DASHBOARD</div>} />
            <Route
              path="/admin/dashboard"
              element={
                <ProtectedRoute adminOnly>
                  <div>ADMIN_SECRET_DASHBOARD</div>
                </ProtectedRoute>
              }
            />
          </Routes>
        </MemoryRouter>
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.getByText('RESIDENT_DASHBOARD')).toBeInTheDocument();
      expect(screen.queryByText('ADMIN_SECRET_DASHBOARD')).not.toBeInTheDocument();
    });
  });

  it('redirects resident to /dashboard even if previous attempt was an /admin/* route', async () => {
    const { default: LoginPage } = await import('../pages/LoginPage');
    vi.spyOn(authApi, 'loginUser').mockResolvedValueOnce({
      access_token: 'res.token',
      token_type: 'bearer',
      user: {
        id: 3,
        name: 'Resident Redirect Test',
        email: 'resident_redirect@society.com',
        role: 'RESIDENT',
      },
    });

    render(
      <AuthProvider>
        <MemoryRouter
          initialEntries={[
            { pathname: '/login', state: { from: { pathname: '/admin/settings' } } },
          ]}
        >
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/dashboard" element={<div>RESIDENT_LANDING_PAGE</div>} />
            <Route path="/admin/settings" element={<div>ADMIN_SETTINGS_PAGE</div>} />
          </Routes>
        </MemoryRouter>
      </AuthProvider>
    );

    const emailInput = screen.getByLabelText(/Email Address/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const submitBtn = screen.getByRole('button', { name: /Sign In/i });

    const { fireEvent } = await import('@testing-library/react');
    fireEvent.change(emailInput, { target: { value: 'resident_redirect@society.com' } });
    fireEvent.change(passwordInput, { target: { value: 'Password123' } });
    fireEvent.click(submitBtn);

    await waitFor(() => {
      expect(screen.getByText('RESIDENT_LANDING_PAGE')).toBeInTheDocument();
      expect(screen.queryByText('ADMIN_SETTINGS_PAGE')).not.toBeInTheDocument();
    });
  });

  it('redirects admin to /admin/dashboard upon login', async () => {
    const { default: LoginPage } = await import('../pages/LoginPage');
    vi.spyOn(authApi, 'loginUser').mockResolvedValueOnce({
      access_token: 'adm.token',
      token_type: 'bearer',
      user: {
        id: 4,
        name: 'Admin Redirect Test',
        email: 'admin_redirect@society.com',
        role: 'ADMIN',
      },
    });

    render(
      <AuthProvider>
        <MemoryRouter initialEntries={['/login']}>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/admin/dashboard" element={<div>ADMIN_LANDING_PAGE</div>} />
            <Route path="/dashboard" element={<div>RESIDENT_LANDING_PAGE</div>} />
          </Routes>
        </MemoryRouter>
      </AuthProvider>
    );

    const emailInput = screen.getByLabelText(/Email Address/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const submitBtn = screen.getByRole('button', { name: /Sign In/i });

    const { fireEvent } = await import('@testing-library/react');
    fireEvent.change(emailInput, { target: { value: 'admin_redirect@society.com' } });
    fireEvent.change(passwordInput, { target: { value: 'Password123' } });
    fireEvent.click(submitBtn);

    await waitFor(() => {
      expect(screen.getByText('ADMIN_LANDING_PAGE')).toBeInTheDocument();
      expect(screen.queryByText('RESIDENT_LANDING_PAGE')).not.toBeInTheDocument();
    });
  });

  it('clicking Admin Demo button fills credentials into form without auto-submitting', async () => {
    const { default: LoginPage } = await import('../pages/LoginPage');
    const { fireEvent } = await import('@testing-library/react');

    const loginSpy = vi.spyOn(authApi, 'loginUser');

    render(
      <AuthProvider>
        <MemoryRouter initialEntries={['/login']}>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
          </Routes>
        </MemoryRouter>
      </AuthProvider>
    );

    const emailInput = screen.getByLabelText(/Email Address/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const adminDemoBtn = screen.getByRole('button', { name: /Admin Demo/i });

    // Initially empty
    expect(emailInput.value).toBe('');
    expect(passwordInput.value).toBe('');

    // Click Admin Demo button
    fireEvent.click(adminDemoBtn);

    // Form is populated with demo credentials
    expect(emailInput.value).toBe('admin.demo@society-tracker.com');
    expect(passwordInput.value).toBe('DemoAdmin@2026');

    // Does NOT auto-submit
    expect(loginSpy).not.toHaveBeenCalled();
  });

  it('clicking Resident Demo button fills credentials into form without auto-submitting', async () => {
    const { default: LoginPage } = await import('../pages/LoginPage');
    const { fireEvent } = await import('@testing-library/react');

    const loginSpy = vi.spyOn(authApi, 'loginUser');

    render(
      <AuthProvider>
        <MemoryRouter initialEntries={['/login']}>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
          </Routes>
        </MemoryRouter>
      </AuthProvider>
    );

    const emailInput = screen.getByLabelText(/Email Address/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const residentDemoBtn = screen.getByRole('button', { name: /Resident Demo/i });

    // Initially empty
    expect(emailInput.value).toBe('');
    expect(passwordInput.value).toBe('');

    // Click Resident Demo button
    fireEvent.click(residentDemoBtn);

    // Form is populated with demo credentials
    expect(emailInput.value).toBe('resident.demo@society-tracker.com');
    expect(passwordInput.value).toBe('DemoResident@2026');

    // Does NOT auto-submit
    expect(loginSpy).not.toHaveBeenCalled();
  });

  it('GuestOnlyRoute redirects authenticated resident to /dashboard on / or /signin or /signup', async () => {
    const { default: GuestOnlyRoute } = await import('../components/common/GuestOnlyRoute');
    const authValue = {
      user: { id: 1, name: 'Alice Resident', role: 'RESIDENT' },
      isAuthenticated: true,
      isAdmin: false,
      loading: false,
    };

    render(
      <AuthContext.Provider value={authValue}>
        <MemoryRouter initialEntries={['/signin']}>
          <Routes>
            <Route
              path="/signin"
              element={
                <GuestOnlyRoute>
                  <div>GUEST_SIGNIN_PAGE</div>
                </GuestOnlyRoute>
              }
            />
            <Route path="/dashboard" element={<div>RESIDENT_DASHBOARD_LANDING</div>} />
          </Routes>
        </MemoryRouter>
      </AuthContext.Provider>
    );

    expect(screen.getByText('RESIDENT_DASHBOARD_LANDING')).toBeInTheDocument();
    expect(screen.queryByText('GUEST_SIGNIN_PAGE')).not.toBeInTheDocument();
  });

  it('GuestOnlyRoute redirects authenticated admin to /admin/dashboard on / or /signin', async () => {
    const { default: GuestOnlyRoute } = await import('../components/common/GuestOnlyRoute');
    const authValue = {
      user: { id: 2, name: 'Admin Boss', role: 'ADMIN' },
      isAuthenticated: true,
      isAdmin: true,
      loading: false,
    };

    render(
      <AuthContext.Provider value={authValue}>
        <MemoryRouter initialEntries={['/']}>
          <Routes>
            <Route
              path="/"
              element={
                <GuestOnlyRoute>
                  <div>LANDING_PAGE_CONTENT</div>
                </GuestOnlyRoute>
              }
            />
            <Route path="/admin/dashboard" element={<div>ADMIN_DASHBOARD_LANDING</div>} />
          </Routes>
        </MemoryRouter>
      </AuthContext.Provider>
    );

    expect(screen.getByText('ADMIN_DASHBOARD_LANDING')).toBeInTheDocument();
    expect(screen.queryByText('LANDING_PAGE_CONTENT')).not.toBeInTheDocument();
  });

  it('redirects logged-out visit to /complaints, /new-complaint, and /notices to /signin', async () => {
    const authValue = {
      user: null,
      isAuthenticated: false,
      isAdmin: false,
      loading: false,
    };

    for (const routePath of ['/dashboard', '/complaints', '/new-complaint', '/notices']) {
      const { unmount } = render(
        <AuthContext.Provider value={authValue}>
          <MemoryRouter initialEntries={[routePath]}>
            <Routes>
              <Route path="/signin" element={<div>SIGNIN_VIEW_FOR_{routePath}</div>} />
              <Route
                path={routePath}
                element={
                  <ProtectedRoute>
                    <div>PROTECTED_VIEW</div>
                  </ProtectedRoute>
                }
              />
            </Routes>
          </MemoryRouter>
        </AuthContext.Provider>
      );

      expect(screen.getByText(`SIGNIN_VIEW_FOR_${routePath}`)).toBeInTheDocument();
      expect(screen.queryByText('PROTECTED_VIEW')).not.toBeInTheDocument();
      unmount();
    }
  });

  it('supports redirect query parameter on sign in', async () => {
    const { default: LoginPage } = await import('../pages/LoginPage');
    vi.spyOn(authApi, 'loginUser').mockResolvedValueOnce({
      access_token: 'res.token',
      token_type: 'bearer',
      user: {
        id: 5,
        name: 'Query Redirect User',
        role: 'RESIDENT',
      },
    });

    render(
      <AuthProvider>
        <MemoryRouter initialEntries={['/signin?redirect=/complaints/new']}>
          <Routes>
            <Route path="/signin" element={<LoginPage />} />
            <Route path="/complaints/new" element={<div>NEW_COMPLAINT_PAGE</div>} />
            <Route path="/dashboard" element={<div>DEFAULT_DASHBOARD</div>} />
          </Routes>
        </MemoryRouter>
      </AuthProvider>
    );

    const emailInput = screen.getByLabelText(/Email Address/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const submitBtn = screen.getByRole('button', { name: /Sign In/i });

    const { fireEvent } = await import('@testing-library/react');
    fireEvent.change(emailInput, { target: { value: 'query_redirect@society.com' } });
    fireEvent.change(passwordInput, { target: { value: 'Password123' } });
    fireEvent.click(submitBtn);

    await waitFor(() => {
      expect(screen.getByText('NEW_COMPLAINT_PAGE')).toBeInTheDocument();
      expect(screen.queryByText('DEFAULT_DASHBOARD')).not.toBeInTheDocument();
    });
  });

  it('root URL / redirects authenticated resident directly to /dashboard without rendering landing page', async () => {
    const { default: GuestOnlyRoute } = await import('../components/common/GuestOnlyRoute');
    const authValue = {
      user: { id: 10, name: 'Direct Nav Resident', role: 'RESIDENT' },
      isAuthenticated: true,
      isAdmin: false,
      loading: false,
    };

    render(
      <AuthContext.Provider value={authValue}>
        <MemoryRouter initialEntries={['/']}>
          <Routes>
            <Route
              path="/"
              element={
                <GuestOnlyRoute>
                  <div data-testid="landing-content">LANDING_PAGE_HERO</div>
                </GuestOnlyRoute>
              }
            />
            <Route
              path="/dashboard"
              element={<div data-testid="dashboard-content">RESIDENT_DASHBOARD_VIEW</div>}
            />
          </Routes>
        </MemoryRouter>
      </AuthContext.Provider>
    );

    expect(screen.getByTestId('dashboard-content')).toBeInTheDocument();
    expect(screen.queryByTestId('landing-content')).not.toBeInTheDocument();
  });

  it('root URL / renders loading spinner while auth is unresolved and does not render landing page', async () => {
    const { default: GuestOnlyRoute } = await import('../components/common/GuestOnlyRoute');
    const authValue = {
      user: null,
      isAuthenticated: false,
      isAdmin: false,
      loading: true,
    };

    render(
      <AuthContext.Provider value={authValue}>
        <MemoryRouter initialEntries={['/']}>
          <Routes>
            <Route
              path="/"
              element={
                <GuestOnlyRoute>
                  <div data-testid="landing-content">LANDING_PAGE_HERO</div>
                </GuestOnlyRoute>
              }
            />
            <Route
              path="/dashboard"
              element={<div data-testid="dashboard-content">RESIDENT_DASHBOARD_VIEW</div>}
            />
          </Routes>
        </MemoryRouter>
      </AuthContext.Provider>
    );

    expect(screen.getByText('Checking authentication...')).toBeInTheDocument();
    expect(screen.queryByTestId('landing-content')).not.toBeInTheDocument();
    expect(screen.queryByTestId('dashboard-content')).not.toBeInTheDocument();
  });

  it('root URL / renders landing page when user is logged out', async () => {
    const { default: GuestOnlyRoute } = await import('../components/common/GuestOnlyRoute');
    const authValue = {
      user: null,
      isAuthenticated: false,
      isAdmin: false,
      loading: false,
    };

    render(
      <AuthContext.Provider value={authValue}>
        <MemoryRouter initialEntries={['/']}>
          <Routes>
            <Route
              path="/"
              element={
                <GuestOnlyRoute>
                  <div data-testid="landing-content">LANDING_PAGE_HERO</div>
                </GuestOnlyRoute>
              }
            />
            <Route
              path="/dashboard"
              element={<div data-testid="dashboard-content">RESIDENT_DASHBOARD_VIEW</div>}
            />
          </Routes>
        </MemoryRouter>
      </AuthContext.Provider>
    );

    expect(screen.getByTestId('landing-content')).toBeInTheDocument();
    expect(screen.queryByTestId('dashboard-content')).not.toBeInTheDocument();
  });

  it('direct browser refresh at / with cached resident in AuthProvider synchronously redirects to /dashboard without flashing landing', async () => {
    const { default: GuestOnlyRoute } = await import('../components/common/GuestOnlyRoute');
    localStorage.setItem('token', 'valid.resident.token');
    localStorage.setItem(
      'user',
      JSON.stringify({ id: 42, name: 'Refreshed Resident', role: 'RESIDENT' })
    );

    vi.spyOn(authApi, 'getMe').mockResolvedValueOnce({
      id: 42,
      name: 'Refreshed Resident',
      role: 'RESIDENT',
    });

    render(
      <AuthProvider>
        <MemoryRouter initialEntries={['/']}>
          <Routes>
            <Route
              path="/"
              element={
                <GuestOnlyRoute>
                  <div data-testid="landing-content">LANDING_PAGE_HERO</div>
                </GuestOnlyRoute>
              }
            />
            <Route
              path="/dashboard"
              element={<div data-testid="dashboard-content">RESIDENT_DASHBOARD_VIEW</div>}
            />
          </Routes>
        </MemoryRouter>
      </AuthProvider>
    );

    // Should immediately be on dashboard, no landing content rendered
    expect(screen.getByTestId('dashboard-content')).toBeInTheDocument();
    expect(screen.queryByTestId('landing-content')).not.toBeInTheDocument();
    expect(screen.queryByText('Checking authentication...')).not.toBeInTheDocument();
  });

  it('authenticated user navigating to /signin or /signup redirects to /dashboard', async () => {
    const { default: GuestOnlyRoute } = await import('../components/common/GuestOnlyRoute');
    const authValue = {
      user: { id: 7, name: 'Active Resident', role: 'RESIDENT' },
      isAuthenticated: true,
      isAdmin: false,
      loading: false,
    };

    for (const routePath of ['/signin', '/signup']) {
      const { unmount } = render(
        <AuthContext.Provider value={authValue}>
          <MemoryRouter initialEntries={[routePath]}>
            <Routes>
              <Route
                path={routePath}
                element={
                  <GuestOnlyRoute>
                    <div data-testid="guest-auth-page">AUTH_PAGE_FOR_{routePath}</div>
                  </GuestOnlyRoute>
                }
              />
              <Route
                path="/dashboard"
                element={<div data-testid="dashboard-content">RESIDENT_DASHBOARD_VIEW</div>}
              />
            </Routes>
          </MemoryRouter>
        </AuthContext.Provider>
      );

      expect(screen.getByTestId('dashboard-content')).toBeInTheDocument();
      expect(screen.queryByTestId('guest-auth-page')).not.toBeInTheDocument();
      unmount();
    }
  });

  it('logging out restores access to / to render landing page', async () => {
    const { default: GuestOnlyRoute } = await import('../components/common/GuestOnlyRoute');
    const { useNavigate } = await import('react-router-dom');
    localStorage.setItem('token', 'logout.test.token');
    localStorage.setItem(
      'user',
      JSON.stringify({ id: 99, name: 'Logout User', role: 'RESIDENT' })
    );

    function FullAppSimulator() {
      const { logout } = useAuth();
      const navigate = useNavigate();
      return (
        <div>
          <button
            onClick={() => {
              logout();
              navigate('/');
            }}
            data-testid="logout-btn"
          >
            Log out
          </button>
          <Routes>
            <Route
              path="/"
              element={
                <GuestOnlyRoute>
                  <div data-testid="landing-content">LANDING_PAGE_HERO</div>
                </GuestOnlyRoute>
              }
            />
            <Route
              path="/dashboard"
              element={<div data-testid="dashboard-content">RESIDENT_DASHBOARD_VIEW</div>}
            />
          </Routes>
        </div>
      );
    }

    const { fireEvent } = await import('@testing-library/react');

    render(
      <AuthProvider>
        <MemoryRouter initialEntries={['/']}>
          <FullAppSimulator />
        </MemoryRouter>
      </AuthProvider>
    );

    // Initially authenticated: redirected to dashboard
    expect(screen.getByTestId('dashboard-content')).toBeInTheDocument();
    expect(screen.queryByTestId('landing-content')).not.toBeInTheDocument();

    // Trigger logout
    fireEvent.click(screen.getByTestId('logout-btn'));

    // Now on /, landing page is rendered
    await waitFor(() => {
      expect(screen.getByTestId('landing-content')).toBeInTheDocument();
      expect(screen.queryByTestId('dashboard-content')).not.toBeInTheDocument();
    });
  });

  describe('UI Layout Isolation & Authenticated Navbar Isolation', () => {
    it('rendering / for unauthenticated user does not render any authenticated Navbar elements or links', async () => {
      const { default: App } = await import('../App');

      render(<App />);

      // The public landing page is rendered
      expect(
        screen.getByRole('heading', { name: /A calmer way to care for your society\./i })
      ).toBeInTheDocument();

      // Authenticated Navbar links must NOT exist in the DOM
      expect(screen.queryByRole('link', { name: /My Complaints/i })).not.toBeInTheDocument();
      expect(screen.queryByRole('link', { name: /New Complaint/i })).not.toBeInTheDocument();
      expect(screen.queryByRole('button', { name: /Open account menu/i })).not.toBeInTheDocument();

      // Public landing navigation items SHOULD exist
      expect(screen.getAllByRole('link', { name: /Sign in/i }).length).toBeGreaterThan(0);
      expect(screen.getAllByRole('link', { name: /Get started/i }).length).toBeGreaterThan(0);
    });

    it('rendering /dashboard for authenticated resident mounts the Authenticated Navbar', async () => {
      const { default: Navbar } = await import('../components/common/Navbar');
      const authValue = {
        user: { id: 55, name: 'Alice Resident', role: 'RESIDENT', flat_no: 'B-101' },
        isAuthenticated: true,
        isAdmin: false,
        loading: false,
      };

      render(
        <AuthContext.Provider value={authValue}>
          <MemoryRouter initialEntries={['/dashboard']}>
            <Navbar />
            <div data-testid="page-body">RESIDENT_DASHBOARD</div>
          </MemoryRouter>
        </AuthContext.Provider>
      );

      // Authenticated Navbar is present
      expect(screen.getByRole('navigation')).toBeInTheDocument();
      expect(screen.getByRole('link', { name: /Dashboard/i })).toBeInTheDocument();
      expect(screen.getByRole('link', { name: /My Complaints/i })).toBeInTheDocument();
      expect(screen.getByRole('link', { name: /New Complaint/i })).toBeInTheDocument();
      expect(screen.getByRole('link', { name: /Notices/i })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /Open account menu/i })).toBeInTheDocument();
    });

    it('navigating from /dashboard to / unmounts the Authenticated Navbar completely', async () => {
      const { default: Navbar } = await import('../components/common/Navbar');
      const { default: GuestOnlyRoute } = await import('../components/common/GuestOnlyRoute');
      const { useNavigate } = await import('react-router-dom');

      function Switcher() {
        const navigate = useNavigate();
        return (
          <div>
            <button onClick={() => navigate('/')} data-testid="go-to-root">
              Go to Root
            </button>
            <Routes>
              <Route
                path="/dashboard"
                element={
                  <div>
                    <Navbar />
                    <div data-testid="dashboard-view">DASHBOARD_BODY</div>
                  </div>
                }
              />
              <Route
                path="/"
                element={
                  <GuestOnlyRoute>
                    <div data-testid="clean-landing">CLEAN_LANDING_PAGE</div>
                  </GuestOnlyRoute>
                }
              />
            </Routes>
          </div>
        );
      }

      const { fireEvent } = await import('@testing-library/react');

      // Unauthenticated state
      const authValue = {
        user: null,
        isAuthenticated: false,
        isAdmin: false,
        loading: false,
      };

      render(
        <AuthContext.Provider value={authValue}>
          <MemoryRouter initialEntries={['/dashboard']}>
            <Switcher />
          </MemoryRouter>
        </AuthContext.Provider>
      );

      // On /dashboard, navbar is rendered
      expect(screen.getByTestId('dashboard-view')).toBeInTheDocument();

      // Navigate to /
      fireEvent.click(screen.getByTestId('go-to-root'));

      // On /, landing is rendered and navbar is completely unmounted from DOM
      expect(screen.getByTestId('clean-landing')).toBeInTheDocument();
      expect(screen.queryByTestId('dashboard-view')).not.toBeInTheDocument();
      expect(screen.queryByRole('navigation')).not.toBeInTheDocument();
      expect(screen.queryByRole('link', { name: /My Complaints/i })).not.toBeInTheDocument();
    });
  });
});



